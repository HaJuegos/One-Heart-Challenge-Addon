/*
This file belongs to: "conveex" (Ha Juegos Copyright 2022), Any unauthorized modification or change will be penalized, more information to authorize your copies you can contact me on discord: https://discord.gg/p6a7tqVJxn | Convex's GitHub: https://github.com/conveex
 *********************************************************************
Este archivo pertenece a: "conveex" (Ha Juegos Copyright 2022), Cualquier modificación o cambio no autorizado será sancionado, más información para autorizar tus copias puedes contactar conmigo en discord: https://discord.gg/p6a7tqVJxn | GitHub de Convex: https://github.com/conveex
*/
import{world}
from"mojang-minecraft";world.events.tick.subscribe(eventTick=>{for(const plr of world.getPlayers()){let health=plr.getComponent('minecraft:health');if(health.current==0&&!plr.hasTag("Dead")){world.getDimension("overworld").runCommand(`tellraw @a {"rawtext":[{"translate":"message.coordinates.dead.player"},{"text":" ${Math.floor(plr.location.x)} ${Math.floor(plr.location.y)} ${Math.floor(plr.location.z)} (${getDimension(plr.dimension)})"}]}`)
plr.addTag("Dead")
plr.addTag("playerspec")}
if(plr.hasTag("playerspec")&&plr.hasTag("Dead")){}}})
function getDimension(dimension){const ids=['overworld','nether','the end'];let d=ids.find((id)=>world.getDimension(id)==dimension);switch(d){case"overworld":{return`§aOverworld§7`}
break;case"nether":{return`§cNether§7`}
break;case"the end":{return`§9The End§7`}
break;}}
function runCommand(command){try{return{error:false,...world.getDimension('overworld').runCommand(command)};}catch(error){return{error:true};};};
/*
This file belongs to: "conveex" (Ha Juegos Copyright 2022), Any unauthorized modification or change will be penalized, more information to authorize your copies you can contact me on discord: https://discord.gg/p6a7tqVJxn | Convex's GitHub: https://github.com/conveex
 *********************************************************************
Este archivo pertenece a: "conveex" (Ha Juegos Copyright 2022), Cualquier modificación o cambio no autorizado será sancionado, más información para autorizar tus copias puedes contactar conmigo en discord: https://discord.gg/p6a7tqVJxn | GitHub de Convex: https://github.com/conveex
*/